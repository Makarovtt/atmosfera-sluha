import BasketComponent from "@/components/basket/basket-page";

export default function BasketPage() {
	return (
		<>
			<BasketComponent />
		</>
	);
}
