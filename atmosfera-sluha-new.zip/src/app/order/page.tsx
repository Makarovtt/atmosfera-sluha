import OrderComponent from "@/components/order/order-page";

export default function OrderPage() {
	return (
		<>
			<OrderComponent />
		</>
	);
}
